
Author - Vladimir Shepel ( @vlshepel )

________

Free use for personal and commercial use.